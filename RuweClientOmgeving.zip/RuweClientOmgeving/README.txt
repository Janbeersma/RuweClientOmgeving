Dit is een RuweClientOmgeving betekenende
dat alles wat hierin staat nog work in progress is.

In het specifiek staat in dit project het POJO naar JSON gedeelte (wordt gerefereerd in deskresearch)
dit gaat in de toekomst worden gedaan met JSON-B maar is voor nu nog met JACKSON.