package POJOs;

import com.fasterxml.jackson.annotation.*;

import java.util.UUID;

@JsonRootName(value = "portEnv")
@JsonPropertyOrder({"id", "portingName", "message"})
public class PortEnv {
    public UUID id;
    public String portingName;
    public Message message;

    public PortEnv(UUID id, String portingName, Message message) {
        this.id = id;
        this.portingName = portingName;
        this.message = message;
    }

    @JsonProperty("id")
    public UUID getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(UUID id) {
        this.id = id;
    }

    @JsonProperty("portingName")
    public String getPortingName() {
        return portingName;
    }

    @JsonProperty("portingName")
    public void setPortingName(String portingName) {
        this.portingName = portingName;
    }

    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "testmessage")
    public Message getMessage() {
        return message;
    }

    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "testmessage")
    public void setMessage(Message message) {
        this.message = message;
    }
}
