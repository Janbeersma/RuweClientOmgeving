package POJOs;

import com.fasterxml.jackson.annotation.*;

@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "testmessage")
@JsonRootName(value = "message")
@JsonPropertyOrder("testmessage")
public class Message {
    public String testmessage;

    public Message(String testmessage) {
        this.testmessage = testmessage;
    }

    @JsonProperty
    public String getTestmessage() {
        return testmessage;
    }

    @JsonProperty
    public void setTestmessage(String testmessage) {
        this.testmessage = testmessage;
    }
}

