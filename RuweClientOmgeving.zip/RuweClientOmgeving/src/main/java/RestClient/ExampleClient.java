package RestClient;

import POJOs.Message;
import POJOs.PortEnv;

import javax.ws.rs.client.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.UUID;

public class ExampleClient {

    public static void main(String[] args){
        Client client = ClientBuilder.newClient();
        WebTarget webTarget = client.target("http://localhost:8080/api/v1/").path("portenv");

        Message message = new Message("dit is de geneste message");
        PortEnv portEnv = new PortEnv(UUID.randomUUID(),"Dit is een test kek of niet dan?", message);

        Invocation.Builder invb = webTarget.request(MediaType.APPLICATION_JSON_TYPE);
        Response response = invb.post(Entity.entity(portEnv, MediaType.APPLICATION_JSON_TYPE));

        //PortEnv  = response.readEntity(Message.class);
    }
}


